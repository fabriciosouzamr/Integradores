﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Host;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace WebHook_ChatAPI
{
    public static class MessageWebHook
    {
        public static ManualResetEvent allDone = new ManualResetEvent(false);

        [FunctionName("MessageWebHook")]
        public static async Task<HttpResponseMessage> Run([HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)]HttpRequestMessage req, TraceWriter log)
        {
            log.Info("C# HTTP trigger function processed a request.");

            dynamic data = await req.Content.ReadAsAsync<JObject>();

            string sfromMe = "";
            string schatId = "";
            string sbody = "";
            string stype = "";

            JObject my_obj = JsonConvert.DeserializeObject<JObject>(data.ToString());

            Dictionary<string, JToken> dict = JsonConvert.DeserializeObject<Dictionary<string, JToken>>(my_obj.ToString());

            foreach (KeyValuePair<string, JToken> Item in dict)
            {
                sfromMe = ((JObject)((JArray)Item.Value).First)["fromMe"].ToString();
                schatId = ((JObject)((JArray)Item.Value).First)["chatId"].ToString();
                sbody = ((JObject)((JArray)Item.Value).First)["body"].ToString();
                stype = ((JObject)((JArray)Item.Value).First)["type"].ToString();
                break;
            }

            if (sfromMe.Trim().ToUpper() == "FALSE" && stype.Trim().ToUpper() == "CHAT")
            {
                try
                {
                    //var json = new { phone = "17472822486", body = "Hello, world!" };

                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(new Uri("https://eu29.chat-api.com/instance18590/message?token=rh56r027e7oybvgd"));

                    //request.Method = "POST";
                    //request.ContentType = "application/json; charset=utf-8";
                    //request.AutomaticDecompression = DecompressionMethods.Deflate | DecompressionMethods.GZip;
                    //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

                    //ASCIIEncoding encoding = new ASCIIEncoding();
                    //Byte[] bytes = encoding.GetBytes(json.ToString());
                    //request.ContentLength = bytes.Length;

                    //RequestState myRequestState = new RequestState();
                    //myRequestState.request = request;

                    //// Set the 'Method' property  to 'POST' to post data to a Uri.
                    //myRequestState.request.Method = "POST";

                    //Stream newStream = request.GetRequestStream();
                    //newStream.Write(bytes, 0, bytes.Length);

                    //IAsyncResult r = (IAsyncResult)request.BeginGetRequestStream(new AsyncCallback(ReadCallback), myRequestState);

                    //using (var response = (HttpWebResponse)request.GetResponse())
                    //{
                    //    using (var stream = response.GetResponseStream())
                    //    {
                    //        using (var sr = new StreamReader(stream))
                    //        {
                    //            var content = sr.ReadToEnd();
                    //        }
                    //    }
                    //}

                    request.ContentType = "application/json";
                    request.Method = "POST";
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;

                    if (sbody.Trim().ToUpper().IndexOf("OLÁ") > -1 || sbody.Trim().ToUpper().IndexOf("OLA") > -1)
                    {
                        sbody = "Ola! Sou a Alice, Assistente Virtual! :)";
                    }
                    else if (sbody.Trim().ToUpper().IndexOf("OLÁ") > -1 || sbody.Trim().ToUpper().IndexOf("OLA") > -1)
                    {
                        sbody = "Ola! Sou a Alice, Assistente Virtual! :)";
                    }
                    else if (sbody.Trim().ToUpper().IndexOf("OBRIGADO") > -1 || sbody.Trim().ToUpper().IndexOf("GRATO") > -1)
                    {
                        sbody = "Estou aqui para ajudar ;)";
                    }
                    else
                    {
                        sbody = "Sou uma assistente virtual e ainda estou aprendendo.";
                    }

                    using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                    {
                        string json = new JavaScriptSerializer().Serialize(new
                        {
                            chatId = schatId,
                            body = sbody
                        });
                        streamWriter.Write(json);
                        streamWriter.Flush();
                        streamWriter.Close();
                    }

                    var httpResponse = (HttpWebResponse)request.GetResponse();
                    using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                    {
                        var result = streamReader.ReadToEnd();
                    }
                }
                catch (Exception Ex)
                {
                }
            }

            return null;
        }

        public class RequestState
        {
            // This class stores the request state of the request.
            public WebRequest request;
            public RequestState()
            {
                request = null;
            }
        }

        private static void ReadCallback(IAsyncResult asynchronousResult)
        {
            RequestState myRequestState = (RequestState)asynchronousResult.AsyncState;
            WebRequest myWebRequest = myRequestState.request;

            // End the Asynchronus request.
            Stream streamResponse = myWebRequest.EndGetRequestStream(asynchronousResult);

            // Create a string that is to be posted to the uri.
            Console.WriteLine("Please enter a string to be posted:");
            string postData = Console.ReadLine();
            // Convert the string into a byte array.
            byte[] byteArray = Encoding.UTF8.GetBytes(postData);

            // Write the data to the stream.
            streamResponse.Write(byteArray, 0, postData.Length);
            streamResponse.Close();
            allDone.Set();
        }
    }
}
